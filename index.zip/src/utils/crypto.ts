import CryptoJS from 'crypto-js';

// Clave maestra para el cifrado de la URL (debería estar en una variable de entorno en producción)
const URL_ENCRYPTION_KEY = 'clave-maestra-segura-para-url-123';

/**
 * Cifra una clave secreta para ser usada en una URL
 * @param secretKey Clave a cifrar
 * @returns Clave cifrada en formato seguro para URL
 */
export const encryptSecretKey = (secretKey: string): string => {
  try {
    const encrypted = CryptoJS.AES.encrypt(secretKey, URL_ENCRYPTION_KEY).toString();
    return encodeURIComponent(encrypted);
  } catch (error) {
    console.error('Error al cifrar la clave secreta:', error);
    throw new Error('Error al cifrar la clave secreta');
  }
};

/**
 * Descifra una clave secreta de una URL
 * @param encryptedKey Clave cifrada de la URL
 * @returns Clave secreta original
 */
export const decryptSecretKey = (encryptedKey: string): string => {
  try {
    const decodedKey = decodeURIComponent(encryptedKey);
    const bytes = CryptoJS.AES.decrypt(decodedKey, URL_ENCRYPTION_KEY);
    const decryptedKey = bytes.toString(CryptoJS.enc.Utf8);
    
    if (!decryptedKey) {
      throw new Error('Clave de cifrado inválida');
    }
    
    return decryptedKey;
  } catch (error) {
    console.error('Error al descifrar la clave secreta:', error);
    throw new Error('Clave de cifrado inválida o corrupta');
  }
};

/**
 * Cifra un objeto JSON usando AES con una clave secreta proporcionada
 * @param data Objeto a cifrar
 * @param secretKey Clave secreta para el cifrado
 * @returns String cifrado en formato base64
 */
export const encryptData = (data: object, secretKey: string): string => {
  if (!secretKey) {
    throw new Error('Se requiere una clave secreta para el cifrado');
  }
  
  try {
    const jsonString = JSON.stringify(data);
    const encrypted = CryptoJS.AES.encrypt(jsonString, secretKey);
    return encrypted.toString();
  } catch (error) {
    console.error('Error al cifrar los datos:', error);
    throw new Error('Error al cifrar los datos');
  }
};

/**
 * Descifra un string cifrado con AES usando una clave secreta
 * @param cipherText Texto cifrado en formato base64
 * @param secretKey Clave secreta para el descifrado
 * @returns Objeto descifrado
 */
export const decryptData = (cipherText: string, secretKey: string): any => {
  if (!secretKey) {
    throw new Error('Se requiere una clave secreta para el descifrado');
  }
  
  try {
    const bytes = CryptoJS.AES.decrypt(cipherText, secretKey);
    const decryptedData = bytes.toString(CryptoJS.enc.Utf8);
    
    if (!decryptedData) {
      throw new Error('Clave secreta incorrecta o datos corruptos');
    }
    
    return JSON.parse(decryptedData);
  } catch (error) {
    console.error('Error al descifrar los datos:', error);
    throw new Error('Error al descifrar los datos. Verifica la clave secreta.');
  }
};

// Ejemplo de uso:
/*
const data = { test: 'datos de prueba' };
const encrypted = encryptData(data);
console.log('Cifrado:', encrypted);

const decrypted = decryptData(encrypted);
console.log('Descifrado:', decrypted);
*/
